import { db, doc, setDoc, onSnapshot } from './firebase-config.js';
import { Utils } from './utils.js';

// 計算機クラス
export class Calculator {
    constructor() {
        this.expression = '';
    }

    show() {
        document.getElementById('calculatorModal').classList.add('show');
        this.clear();
    }

    close() {
        document.getElementById('calculatorModal').classList.remove('show');
    }

    clear() {
        this.expression = '';
        document.getElementById('calcDisplay').textContent = '0';
    }

    append(value) {
        if (this.expression === '0' || this.expression === 'エラー') {
            this.expression = value;
        } else {
            this.expression += value;
        }
        document.getElementById('calcDisplay').textContent = this.expression;
    }

    calculate() {
        try {
            let expression = this.expression.replace(/×/g, '*').replace(/÷/g, '/');
            let result = eval(expression);
            result = Math.round(result * 100) / 100;
            this.expression = result.toString();
            document.getElementById('calcDisplay').textContent = result;
        } catch (error) {
            document.getElementById('calcDisplay').textContent = 'エラー';
            this.expression = 'エラー';
        }
    }

    copyResult() {
        const result = document.getElementById('calcDisplay').textContent;
        if (result && result !== '0' && result !== 'エラー') {
            const textarea = document.createElement('textarea');
            textarea.value = result;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.select();
            
            try {
                document.execCommand('copy');
                document.body.removeChild(textarea);
                Utils.showToast('コピーしました！');
            } catch (err) {
                document.body.removeChild(textarea);
                Utils.showToast('コピーに失敗しました');
            }
        }
    }
}

// CSV出力クラス
export class CSVExporter {
    constructor(budgetManager) {
        this.budgetManager = budgetManager;
    }

    showModal() {
        document.getElementById('csvModal').classList.add('show');
    }

    closeModal() {
        document.getElementById('csvModal').classList.remove('show');
    }

    toggleDateRange() {
        const rangeType = document.getElementById('csvRangeType').value;
        const dateRangeInputs = document.getElementById('dateRangeInputs');
        
        if (rangeType === 'range') {
            dateRangeInputs.style.display = 'block';
            const today = new Date();
            const currentMonth = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0');
            document.getElementById('csvStartDate').value = currentMonth;
            document.getElementById('csvEndDate').value = currentMonth;
        } else {
            dateRangeInputs.style.display = 'none';
        }
    }

    export() {
        const rangeType = document.getElementById('csvRangeType').value;
        const includeNotes = document.getElementById('csvIncludeNotes').checked;
        const includeHalf = document.getElementById('csvIncludeHalf').checked;
        
        let monthsToExport = [];
        const budgetData = this.budgetManager.data;
        
        if (rangeType === 'current') {
            monthsToExport.push(this.budgetManager.getCurrentMonthKey());
        } else if (rangeType === 'all') {
            monthsToExport = Object.keys(budgetData).sort();
        } else if (rangeType === 'range') {
            const startDate = document.getElementById('csvStartDate').value;
            const endDate = document.getElementById('csvEndDate').value;
            
            if (!startDate || !endDate) {
                alert('開始年月と終了年月を選択してください');
                return;
            }
            
            const start = new Date(startDate + '-01');
            const end = new Date(endDate + '-01');
            
            if (start > end) {
                alert('開始年月は終了年月より前に設定してください');
                return;
            }
            
            Object.keys(budgetData).forEach(key => {
                const date = new Date(key + '-01');
                if (date >= start && date <= end) {
                    monthsToExport.push(key);
                }
            });
            
            monthsToExport.sort();
        }
        
        if (monthsToExport.length === 0) {
            alert('出力するデータがありません');
            return;
        }
        
        let csvContent = '\uFEFF';
        let headers = ['年月', '大カテゴリー', '小カテゴリー', '金額'];
        if (includeHalf) headers.push('折半金額');
        if (includeNotes) headers.push('備考');
        csvContent += headers.join(',') + '\n';
        
        monthsToExport.forEach(monthKey => {
            const monthData = budgetData[monthKey];
            if (!monthData || !monthData.categories) return;
            
            monthData.categories.forEach(category => {
                if (category.subcategories && category.subcategories.length > 0) {
                    category.subcategories.forEach(sub => {
                        let row = [
                            monthKey,
                            '"' + category.name + '"',
                            '"' + sub.name + '"',
                            sub.amount || 0
                        ];
                        
                        if (includeHalf) row.push(Math.round((sub.amount || 0) / 2));
                        if (includeNotes) row.push('"' + (sub.note || '') + '"');
                        
                        csvContent += row.join(',') + '\n';
                    });
                } else {
                    let row = [
                        monthKey,
                        '"' + category.name + '"',
                        '',
                        category.amount || 0
                    ];
                    
                    if (includeHalf) row.push(Math.round((category.amount || 0) / 2));
                    if (includeNotes) row.push('"' + (category.note || '') + '"');
                    
                    csvContent += row.join(',') + '\n';
                }
            });
        });
        
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        
        const filename = rangeType === 'current' 
            ? '家計簿_' + this.budgetManager.getCurrentMonthKey() + '.csv'
            : rangeType === 'all'
            ? '家計簿_全期間.csv'
            : '家計簿_' + document.getElementById('csvStartDate').value + '_' + document.getElementById('csvEndDate').value + '.csv';
        
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        Utils.showToast('CSVファイルをダウンロードしました');
        this.closeModal();
    }
}

// 予算管理クラス
export class BudgetManager {
    constructor() {
        this.currentYear = new Date().getFullYear();
        this.currentMonth = new Date().getMonth() + 1;
        this.data = {};
        this.isInitialLoad = true;
    }

    getCurrentMonthKey() {
        return this.currentYear + '-' + String(this.currentMonth).padStart(2, '0');
    }

    getCurrentMonthData() {
        const key = this.getCurrentMonthKey();
        if (!this.data[key]) {
            this.data[key] = { categories: [] };
        }
        return this.data[key];
    }

    showSyncStatus(status, message) {
        const statusEl = document.getElementById('syncStatus');
        statusEl.className = 'sync-status ' + status;
        statusEl.textContent = message;
    }

    async saveToFirestore() {
        try {
            const docRef = doc(db, 'budgetData', 'data');
            await setDoc(docRef, { data: this.data });
            this.showSyncStatus('synced', '✓ 同期完了');
            setTimeout(() => {
                const statusEl = document.getElementById('syncStatus');
                if (statusEl.textContent === '✓ 同期完了') {
                    statusEl.style.display = 'none';
                }
            }, 2000);
        } catch (error) {
            console.error('Firestore保存エラー:', error);
            this.showSyncStatus('error', '✗ 同期エラー: ' + error.message);
        }
    }

    loadFromFirestore() {
        const docRef = doc(db, 'budgetData', 'data');
        
        onSnapshot(docRef, (docSnap) => {
            if (docSnap.exists()) {
                const data = docSnap.data();
                if (data.data) {
                    this.data = data.data;
                    this.updateDisplay();
                    
                    if (this.isInitialLoad) {
                        this.showSyncStatus('synced', '✓ データ読み込み完了');
                        this.isInitialLoad = false;
                        setTimeout(() => {
                            document.getElementById('syncStatus').style.display = 'none';
                        }, 2000);
                    }
                }
            } else {
                this.showSyncStatus('synced', '✓ 接続完了（データなし）');
                setTimeout(() => {
                    document.getElementById('syncStatus').style.display = 'none';
                }, 2000);
            }
        }, (error) => {
            console.error('Firestore読み込みエラー:', error);
            this.showSyncStatus('error', '✗ 接続エラー: ' + error.message);
        });
    }

    changeMonth(delta) {
        this.currentMonth += delta;
        if (this.currentMonth > 12) {
            this.currentMonth = 1;
            this.currentYear++;
        } else if (this.currentMonth < 1) {
            this.currentMonth = 12;
            this.currentYear--;
        }
        
        const monthDisplay = document.getElementById('currentMonth');
        monthDisplay.style.opacity = '0';
        monthDisplay.style.transform = 'scale(0.9)';
        
        setTimeout(() => {
            this.updateDisplay();
            monthDisplay.style.transition = 'all 0.3s ease';
            monthDisplay.style.opacity = '1';
            monthDisplay.style.transform = 'scale(1)';
        }, 150);
    }

    addCategory() {
        const name = document.getElementById('newCategoryName').value.trim();
        const amount = document.getElementById('newCategoryAmount').value;
        const note = document.getElementById('newCategoryNote').value.trim();

        if (!name) {
            alert('カテゴリー名を入力してください');
            return;
        }

        const monthData = this.getCurrentMonthData();
        monthData.categories.push({
            id: Date.now(),
            name: name,
            amount: amount ? parseFloat(amount) : 0,
            note: note,
            subcategories: []
        });

        document.getElementById('newCategoryName').value = '';
        document.getElementById('newCategoryAmount').value = '';
        document.getElementById('newCategoryNote').value = '';
        
        this.showSyncStatus('syncing', '同期中...');
        this.saveToFirestore();
    }

    addSubcategory(categoryId) {
        const name = document.getElementById('subname-' + categoryId).value.trim();
        const amount = document.getElementById('subamount-' + categoryId).value;
        const note = document.getElementById('subnote-' + categoryId).value.trim();

        if (!name) {
            alert('項目名を入力してください');
            return;
        }

        const monthData = this.getCurrentMonthData();
        const category = monthData.categories.find(c => c.id === categoryId);
        
        if (category) {
            category.subcategories.push({
                id: Date.now(),
                name: name,
                amount: amount ? parseFloat(amount) : 0,
                note: note
            });

            document.getElementById('subname-' + categoryId).value = '';
            document.getElementById('subamount-' + categoryId).value = '';
            document.getElementById('subnote-' + categoryId).value = '';
            
            this.showSyncStatus('syncing', '同期中...');
            this.saveToFirestore();
        }
    }

    deleteCategory(categoryId) {
        if (!confirm('このカテゴリーを削除しますか？')) return;

        const monthData = this.getCurrentMonthData();
        monthData.categories = monthData.categories.filter(c => c.id !== categoryId);
        
        this.showSyncStatus('syncing', '同期中...');
        this.saveToFirestore();
    }

    deleteSubcategory(categoryId, subcategoryId) {
        if (!confirm('この項目を削除しますか？')) return;

        const monthData = this.getCurrentMonthData();
        const category = monthData.categories.find(c => c.id === categoryId);
        
        if (category) {
            category.subcategories = category.subcategories.filter(s => s.id !== subcategoryId);
            this.showSyncStatus('syncing', '同期中...');
            this.saveToFirestore();
        }
    }

    editCategory(categoryId) {
        const monthData = this.getCurrentMonthData();
        const category = monthData.categories.find(c => c.id === categoryId);
        
        if (category) {
            const newName = prompt('カテゴリー名を入力:', category.name);
            if (newName !== null && newName.trim()) {
                category.name = newName.trim();
                this.showSyncStatus('syncing', '同期中...');
                this.saveToFirestore();
            }
        }
    }

    editSubcategory(categoryId, subcategoryId) {
        const monthData = this.getCurrentMonthData();
        const category = monthData.categories.find(c => c.id === categoryId);
        
        if (category) {
            const subcategory = category.subcategories.find(s => s.id === subcategoryId);
            if (subcategory) {
                const newName = prompt('項目名を入力:', subcategory.name);
                if (newName !== null && newName.trim()) {
                    subcategory.name = newName.trim();
                    this.showSyncStatus('syncing', '同期中...');
                    this.saveToFirestore();
                }
            }
        }
    }

    updateAmount(categoryId, subcategoryId) {
        const monthData = this.getCurrentMonthData();
        const category = monthData.categories.find(c => c.id === categoryId);
        
        if (category) {
            if (subcategoryId === null) {
                const input = document.getElementById('amount-' + categoryId);
                category.amount = parseFloat(input.value) || 0;
            } else {
                const subcategory = category.subcategories.find(s => s.id === subcategoryId);
                if (subcategory) {
                    const input = document.getElementById('subamount-' + categoryId + '-' + subcategoryId);
                    subcategory.amount = parseFloat(input.value) || 0;
                }
            }
            this.showSyncStatus('syncing', '同期中...');
            this.saveToFirestore();
        }
    }

    updateNote(categoryId, subcategoryId) {
        const monthData = this.getCurrentMonthData();
        const category = monthData.categories.find(c => c.id === categoryId);
        
        if (category) {
            if (subcategoryId === null) {
                const input = document.getElementById('note-' + categoryId);
                category.note = input.value.trim();
            } else {
                const subcategory = category.subcategories.find(s => s.id === subcategoryId);
                if (subcategory) {
                    const input = document.getElementById('subnote-edit-' + categoryId + '-' + subcategoryId);
                    subcategory.note = input.value.trim();
                }
            }
            this.showSyncStatus('syncing', '同期中...');
            this.saveToFirestore();
        }
    }

    toggleAccordion(categoryId) {
        const details = document.getElementById('details-' + categoryId);
        const icon = document.getElementById('icon-' + categoryId);
        
        if (details.classList.contains('open')) {
            details.classList.remove('open');
            icon.classList.remove('open');
        } else {
            details.classList.add('open');
            icon.classList.add('open');
        }
    }

    copyFromPreviousMonth() {
        let prevMonth = this.currentMonth - 1;
        let prevYear = this.currentYear;
        
        if (prevMonth < 1) {
            prevMonth = 12;
            prevYear--;
        }
        
        const prevKey = prevYear + '-' + String(prevMonth).padStart(2, '0');
        
        if (!this.data[prevKey] || !this.data[prevKey].categories || this.data[prevKey].categories.length === 0) {
            alert('先月のデータがありません');
            return;
        }
        
        const currentData = this.getCurrentMonthData();
        if (currentData.categories.length > 0) {
            if (!confirm('今月のデータが上書きされますが、よろしいですか？')) {
                return;
            }
        }
        
        const prevData = this.data[prevKey];
        const copiedCategories = JSON.parse(JSON.stringify(prevData.categories));
        
        copiedCategories.forEach(category => {
            category.id = Date.now() + Math.random();
            category.subcategories.forEach(sub => {
                sub.id = Date.now() + Math.random();
            });
        });
        
        currentData.categories = copiedCategories;
        
        this.showSyncStatus('syncing', '同期中...');
        this.saveToFirestore();
        alert('先月分のデータをコピーしました');
    }

    calculateTotal() {
        const monthData = this.getCurrentMonthData();
        let total = 0;

        monthData.categories.forEach(category => {
            if (category.subcategories.length === 0) {
                total += category.amount || 0;
            } else {
                category.subcategories.forEach(sub => {
                    total += sub.amount || 0;
                });
            }
        });

        return total;
    }

    generateOutput() {
        const monthData = this.getCurrentMonthData();
        const monthKey = this.getCurrentMonthKey();
        const parts = monthKey.split('-');
        const year = parts[0];
        const month = parseInt(parts[1]);
        
        let output = '━━━━━━━━━━━━━━━━\n';
        output += '📅 ' + year + '年' + month + '月 家計簿\n';
        output += '━━━━━━━━━━━━━━━━\n\n';
        
        monthData.categories.forEach((category, index) => {
            if (category.subcategories.length === 0) {
                output += '■ ' + category.name + '：' + category.amount.toLocaleString() + '円\n';
            } else {
                const subTotal = category.subcategories.reduce((sum, sub) => sum + (sub.amount || 0), 0);
                output += '■ ' + category.name + '：' + subTotal.toLocaleString() + '円\n';
                
                category.subcategories.forEach((sub, subIndex) => {
                    const isLast = subIndex === category.subcategories.length - 1;
                    const prefix = isLast ? '  └ ' : '  ├ ';
                    output += prefix + sub.name + '：' + sub.amount.toLocaleString() + '円\n';
                });
            }
            
            if (index < monthData.categories.length - 1) {
                output += '\n';
            }
        });
        
        const total = this.calculateTotal();
        const halfTotal = Math.round(total / 2);
        output += '\n━━━━━━━━━━━━━━━━\n';
        output += '💰 Total：' + total.toLocaleString() + '円\n';
        output += '👥 折半：' + halfTotal.toLocaleString() + '円\n';
        output += '━━━━━━━━━━━━━━━━';
        
        return output;
    }

    updateDisplay() {
        document.getElementById('currentMonth').textContent = this.currentYear + '年 ' + this.currentMonth + '月';

        const monthData = this.getCurrentMonthData();
        let listHtml = '';
        
        monthData.categories.forEach(category => {
            let subcategoriesHtml = '';
            
            category.subcategories.forEach(sub => {
                subcategoriesHtml += '<div class="subcategory-item">';
                subcategoriesHtml += '<div class="sub-row">';
                subcategoriesHtml += '<div>';
                subcategoriesHtml += '<span class="subcategory-name">' + sub.name + '</span>';
                if (sub.note) {
                    subcategoriesHtml += '<div class="note-text">備考: ' + sub.note + '</div>';
                }
                subcategoriesHtml += '</div>';
                subcategoriesHtml += '<div class="category-amount">';
                subcategoriesHtml += '<input type="number" id="subamount-' + category.id + '-' + sub.id + '" value="' + sub.amount + '" onchange="app.budget.updateAmount(' + category.id + ', ' + sub.id + ')">';
                subcategoriesHtml += '<span>円</span>';
                subcategoriesHtml += '<div class="category-actions">';
                subcategoriesHtml += '<button class="edit-btn" onclick="app.budget.editSubcategory(' + category.id + ', ' + sub.id + ')">編集</button>';
                subcategoriesHtml += '<button class="delete-btn" onclick="app.budget.deleteSubcategory(' + category.id + ', ' + sub.id + ')">削除</button>';
                subcategoriesHtml += '</div></div></div>';
                subcategoriesHtml += '<input type="text" class="note-input" id="subnote-edit-' + category.id + '-' + sub.id + '" value="' + (sub.note || '') + '" placeholder="備考を入力..." onchange="app.budget.updateNote(' + category.id + ', ' + sub.id + ')">';
                subcategoriesHtml += '</div>';
            });

            const subTotal = category.subcategories.reduce((sum, sub) => sum + (sub.amount || 0), 0);
            const displayAmount = category.subcategories.length > 0 ? subTotal : category.amount;

            listHtml += '<div class="category-item">';
            
            listHtml += '<div class="category-summary" onclick="app.budget.toggleAccordion(' + category.id + ')">';
            listHtml += '<div class="category-summary-left">';
            listHtml += '<span class="accordion-icon" id="icon-' + category.id + '">▶</span>';
            listHtml += '<span class="category-summary-name">' + category.name + '</span>';
            listHtml += '</div>';
            listHtml += '<span class="category-summary-amount">' + displayAmount.toLocaleString() + '円</span>';
            listHtml += '</div>';
            
            listHtml += '<div class="category-details" id="details-' + category.id + '">';
            listHtml += '<div class="category-header">';
            listHtml += '<div>';
            listHtml += '<span class="category-name">' + category.name + '</span>';
            if (category.note) {
                listHtml += '<div class="note-text">備考: ' + category.note + '</div>';
            }
            listHtml += '</div>';
            listHtml += '<div class="category-amount">';
            
            if (category.subcategories.length === 0) {
                listHtml += '<input type="number" id="amount-' + category.id + '" value="' + category.amount + '" onchange="app.budget.updateAmount(' + category.id + ', null)">';
                listHtml += '<span>円</span>';
            } else {
                listHtml += '<span style="font-size: 18px; font-weight: bold;">合計: ' + displayAmount.toLocaleString() + '円</span>';
            }
            
            listHtml += '<div class="category-actions">';
            listHtml += '<button class="edit-btn" onclick="app.budget.editCategory(' + category.id + ')">編集</button>';
            listHtml += '<button class="delete-btn" onclick="app.budget.deleteCategory(' + category.id + ')">削除</button>';
            listHtml += '</div></div></div>';
            
            if (category.subcategories.length === 0) {
                listHtml += '<div style="margin-top: 10px;">';
                listHtml += '<input type="text" class="note-input" id="note-' + category.id + '" value="' + (category.note || '') + '" placeholder="備考を入力..." onchange="app.budget.updateNote(' + category.id + ', null)">';
                listHtml += '</div>';
            }
            
            if (category.subcategories.length > 0) {
                listHtml += '<div class="subcategory-list">' + subcategoriesHtml + '</div>';
            }
            
            listHtml += '<div class="add-subcategory">';
            listHtml += '<div class="input-group">';
            listHtml += '<input type="text" id="subname-' + category.id + '" placeholder="小カテゴリー（例：電気）">';
            listHtml += '<input type="number" id="subamount-' + category.id + '" placeholder="金額">';
            listHtml += '<input type="text" id="subnote-' + category.id + '" placeholder="備考（任意）">';
            listHtml += '<button onclick="app.budget.addSubcategory(' + category.id + ')">追加</button>';
            listHtml += '</div></div>';
            
            listHtml += '</div>';
            listHtml += '</div>';
        });

        document.getElementById('categoryList').innerHTML = listHtml;

        const total = this.calculateTotal();
        const half = Math.round(total / 2);
        document.getElementById('totalAmount').textContent = '¥' + total.toLocaleString();
        document.getElementById('halfAmount').textContent = '折半: ¥' + half.toLocaleString();
        document.getElementById('outputText').textContent = this.generateOutput();
    }

    copyOutput() {
        const text = document.getElementById('outputText').textContent;
        navigator.clipboard.writeText(text).then(() => {
            const successMsg = document.getElementById('copySuccess');
            successMsg.style.display = 'block';
            setTimeout(() => {
                successMsg.style.display = 'none';
            }, 2000);
        });
    }

    copyHalfAmount() {
        const total = this.calculateTotal();
        const halfTotal = Math.round(total / 2);
        const text = halfTotal.toLocaleString();
        
        navigator.clipboard.writeText(text).then(() => {
            Utils.showToast('コピーしました！');
        }).catch(() => {
            Utils.showToast('コピーに失敗しました');
        });
    }
}
